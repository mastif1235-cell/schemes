-- Блокнот-скан — D1 schema (v2, multi-user)
-- Применять: wrangler d1 execute blocknot --remote --file=schema.sql

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  display_name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL UNIQUE,
  device_name TEXT,
  created_at TEXT NOT NULL,
  last_used_at TEXT,
  expires_at TEXT NOT NULL,
  revoked_at TEXT
);
CREATE INDEX ix_sessions_user ON sessions(user_id);

-- Единый счётчик логических часов для incremental sync.
-- Заполняется отдельным INSERT перед каждой мутацией; last_row_id → seq,
-- который затем пишется в изменяемые строки в той же батч-транзакции.
CREATE TABLE change_seq (
  seq INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL
);

CREATE TABLE notebooks (
  id TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL REFERENCES users(id),
  created_by TEXT NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  description TEXT,
  archived INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1,
  seq INTEGER NOT NULL,
  deleted_at TEXT,
  deleted_by TEXT REFERENCES users(id),
  client_ref TEXT
);
CREATE INDEX ix_notebooks_seq ON notebooks(seq);
CREATE UNIQUE INDEX ux_notebooks_client_ref ON notebooks(created_by, client_ref) WHERE client_ref IS NOT NULL;

CREATE TABLE notebook_members (
  notebook_id TEXT NOT NULL REFERENCES notebooks(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  role TEXT NOT NULL CHECK(role IN ('OWNER','MEMBER')),
  added_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  seq INTEGER NOT NULL,
  revoked_at TEXT,
  PRIMARY KEY (notebook_id, user_id)
);
CREATE INDEX ix_members_user ON notebook_members(user_id);
CREATE INDEX ix_members_notebook ON notebook_members(notebook_id);
CREATE INDEX ix_members_seq ON notebook_members(seq);

CREATE TABLE invites (
  id TEXT PRIMARY KEY,
  notebook_id TEXT NOT NULL REFERENCES notebooks(id),
  code_hash TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK(role IN ('OWNER','MEMBER')),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  expires_at TEXT,
  used_by TEXT REFERENCES users(id),
  used_at TEXT
);
CREATE INDEX ix_invites_notebook ON invites(notebook_id);

CREATE TABLE spreads (
  id TEXT PRIMARY KEY,
  notebook_id TEXT NOT NULL REFERENCES notebooks(id),
  number INTEGER NOT NULL,
  title TEXT,
  note_short TEXT,
  note_full TEXT,
  status TEXT NOT NULL DEFAULT 'Актуально',
  current_photo_id TEXT,
  searchableText TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_by TEXT REFERENCES users(id),
  updated_at TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1,
  seq INTEGER NOT NULL,
  deleted_at TEXT,
  deleted_by TEXT REFERENCES users(id),
  client_ref TEXT
);
CREATE INDEX ix_spreads_notebook ON spreads(notebook_id);
CREATE INDEX ix_spreads_seq ON spreads(seq);
CREATE UNIQUE INDEX ux_spreads_notebook_number ON spreads(notebook_id, number) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX ux_spreads_client_ref ON spreads(created_by, client_ref) WHERE client_ref IS NOT NULL;

CREATE TABLE photos (
  id TEXT PRIMARY KEY,
  spread_id TEXT NOT NULL REFERENCES spreads(id),
  version INTEGER NOT NULL,
  is_current INTEGER NOT NULL DEFAULT 0,
  provider TEXT NOT NULL DEFAULT 'telegram',
  storage_object_id TEXT,
  telegram_message_id INTEGER,
  telegram_file_id TEXT,
  telegram_file_unique_id TEXT,
  mime_type TEXT,
  file_size INTEGER,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  seq INTEGER NOT NULL,
  ocr_text TEXT,
  ocr_status TEXT NOT NULL DEFAULT 'none',
  ocr_updated_at TEXT,
  client_upload_id TEXT UNIQUE
);
CREATE INDEX ix_photos_spread ON photos(spread_id);
CREATE INDEX ix_photos_seq ON photos(seq);
CREATE UNIQUE INDEX ux_photos_spread_version ON photos(spread_id, version);
CREATE UNIQUE INDEX ux_photos_current ON photos(spread_id) WHERE is_current = 1;

-- Маленький thumbnail хранится прямо в D1 как base64 (несколько КБ) —
-- второй телефон получает превью без скачивания полноразмерного оригинала
-- и без необходимости заводить ещё один storage-сервис.
CREATE TABLE photo_previews (
  photo_id TEXT PRIMARY KEY REFERENCES photos(id),
  preview_base64 TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE tags (
  id TEXT PRIMARY KEY,
  notebook_id TEXT NOT NULL REFERENCES notebooks(id),
  name TEXT NOT NULL,
  normalized_name TEXT NOT NULL,
  seq INTEGER NOT NULL,
  deleted_at TEXT
);
CREATE UNIQUE INDEX ux_tags_notebook_norm ON tags(notebook_id, normalized_name);
CREATE INDEX ix_tags_seq ON tags(seq);

CREATE TABLE spread_tags (
  spread_id TEXT NOT NULL REFERENCES spreads(id),
  tag_id TEXT NOT NULL REFERENCES tags(id),
  seq INTEGER NOT NULL,
  deleted_at TEXT,
  PRIMARY KEY (spread_id, tag_id)
);
CREATE INDEX ix_spread_tags_seq ON spread_tags(seq);

CREATE TABLE user_favorites (
  user_id TEXT NOT NULL REFERENCES users(id),
  spread_id TEXT NOT NULL REFERENCES spreads(id),
  seq INTEGER NOT NULL,
  deleted_at TEXT,
  PRIMARY KEY (user_id, spread_id)
);
CREATE INDEX ix_favorites_seq ON user_favorites(seq);

CREATE TABLE history (
  id TEXT PRIMARY KEY,
  notebook_id TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  action TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX ix_history_notebook ON history(notebook_id, created_at);

CREATE TABLE uploads (
  client_upload_id TEXT PRIMARY KEY,
  photo_id TEXT NOT NULL REFERENCES photos(id),
  result_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
